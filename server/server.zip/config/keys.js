module.exports= {
    mongoURI: 'mongodb+srv://Majeed:1122334455@cluster0.lhilx.mongodb.net/csystems?retryWrites=true&w=majority'
}